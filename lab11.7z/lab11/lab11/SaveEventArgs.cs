﻿public class SaveEventArgs : EventArgs
{
    public Item Item { get; set; }
    public string Action { get; set; }
}