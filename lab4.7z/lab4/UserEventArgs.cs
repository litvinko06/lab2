﻿public class UserEventArgs : EventArgs
{
    public User User { get; set; }
    public string Action { get; set; }
}