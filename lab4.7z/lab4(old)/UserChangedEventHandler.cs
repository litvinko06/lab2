namespace lab4.BlazorLab;

public delegate void UserChangedEventHandler(object sender, UserEventArgs e);